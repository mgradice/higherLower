
/* 
   Welcome to the Higher-Lower Game Project. 

   Try out the following functions that are 
   available to you (you can just call them
   in code or the console):
   
  // Returns the current value the user has 
  // entered into the guess input box.
  function getGuessInput()

  // Sets the current value  entered into the 
  // guess input box to 'value'.
  function setGuessInput(value)
 
  // Hides all messages shown to the user within
  // the "message-container" element.
  function hideAllMessages()

  // Hides all messages and then shows the one
  // with with the id attribute matching 'id' 
  // parameter.
  // Example: showMessage("higher-message")
  function showMessage(id)

  // Shows the remaining guess count.
  function showRemainingGuesses(value)
*/

// Initialize global variables needed by the program.
let magicNumber = -1;
let remainingGuesses = 5;


/* Returns a random integer in the range 'min' through 'max' inclusive. 

   This can be taken directly from MDN documentation: 
     https://tinyurl.com/3jkxa8h3

*/
function getRandomIntInclusive(min, max) {
  min = Math.ceil(min);
  max = Math.floor(max);
  return Math.floor(Math.random() * (max - min) + min);
}

// magicNumber = getRandomIntInclusive(1,100);



// /* This function sets up a new game when called. 
//    Here are the steps:

//      (1) Generate a magic number stored in 'magicNumber'.
//      (2) Reset the remaining guess count.
//      (3) Show the new guess count.
//      (4) Hide any messages.

// */

function setupNewGame() {
  magicNumber = getRandomIntInclusive(1,100);
  console.log(magicNumber)
  remainingGuesses = 5;
  showRemainingGuesses(remainingGuesses);
  hideAllMessages();
}   //this function is working

// Handles when the user makes a new guess.
function handleGuess() {
   if (remainingGuesses == -1){
    setupNewGame();
       return;
  }
// Check if the user has any remaining guesses and return if not.
// Retreive the user's newest guess.
  if (remainingGuesses >= 0) {
     getGuessInput();
  } 

  guessNumber = getGuessInput();
 // Check if the user has won. We should show a message, set remaining guesses to 0, and return from this function.
 // Check if the guess is higher or lower and show appropriate message.
  if (guessNumber > magicNumber) {
    showMessage("lower-message");
  } else if (guessNumber < magicNumber) {
    showMessage("higher-message");
  }  

  if (guessNumber == magicNumber) {
    showMessage("win-message");
    showRemainingGuesses(0);
    setupNewGame();
    return;
  } 
 
//   // The user has used a guess, decrement remaining guesses and show the new value.
 for (let i = 1; i > -1; i--) {
   remainingGuesses = remainingGuesses - i;
   showRemainingGuesses(remainingGuesses); 
 } //this is working. 

 // If the remaining guesses is 0, then the user has lost and that message should be shown. this code is working. 
 if (remainingGuesses == -1) {
    showMessage("lose-message");
    showRemainingGuesses(0);
    return;
  }
}


// /* Function to be called when the user wants to play again.

//    Here are the steps:

//       (1) Setup a new game.
//       (2) Set the guess input to "".

// */
function handlePlayAgain() {
  setupNewGame();
  setGuessInput("");
}